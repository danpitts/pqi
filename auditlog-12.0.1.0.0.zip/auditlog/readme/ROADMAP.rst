 * log only operations triggered by some users (currently it logs all users)
 * log read operations does not work on all data models, need investigation
